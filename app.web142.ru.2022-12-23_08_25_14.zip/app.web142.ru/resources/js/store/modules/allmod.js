export default{
	actions:{},
	mutations: {
	},
	state:{
		showContent:{
			nav:false,
			component:{
				name:false,
			},
		},
		pages:false
	}
}