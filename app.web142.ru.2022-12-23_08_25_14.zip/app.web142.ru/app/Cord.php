<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cord extends Model
{
    protected $table = 'cords_car';

    protected $guarded = [];
}
